package java_first;

public class TheGreatestOfGivenABC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		a=55;
		b=35;
		c=75;
		System.out.println("a=55\nb=35\nc=75\nWhich number is above Greatest "
				+ "between a, b and c?");
		if(a>=b && a>=c) 
		
		System.out.println("Greatest number: "+a);
		
		if(b>=a && b>=c) 
		
		System.out.println("Greatest number: "+b);
		
		if(c>=a && c>=b) 
		
		System.out.println("Greatest number: "+c);
	}

}