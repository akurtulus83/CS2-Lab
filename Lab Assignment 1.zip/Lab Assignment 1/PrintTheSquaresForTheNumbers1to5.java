package java_first;

public class PrintTheSquaresForTheNumbers1to5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			int a,b,c,d,e, square;
			a=1;
			b=2;
			c=3;
			d=4;
			e=5;
	
			square = a * a;
			
			System.out.println("The Square of a Given Number  " + a + "  =  " + square);
			
			square = b * b;
			
			System.out.println("The Square of a Given Number  " + b + "  =  " + square);
			
			square = c * c;
			
			System.out.println("The Square of a Given Number  " + c + "  =  " + square);
			
			square = d * d;
			
			System.out.println("The Square of a Given Number  " + d + "  =  " + square);
			
			square = e * e;
			
			System.out.println("The Square of a Given Number  " + e + "  =  " + square);
	}

}
