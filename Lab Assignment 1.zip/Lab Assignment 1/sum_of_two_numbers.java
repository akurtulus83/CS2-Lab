package java_first;

public class sum_of_two_numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int varaible_1, varaible_2, sum;
		varaible_1=55;
		varaible_2=15;
		sum=(varaible_1+varaible_2);
			
		System.out.println(" varaible_1 = 55\n varaible_2 = 15\n varible_1 + varaible_2 = sum\n "
				+ "sum of varaible_1 + varaible_2 is =" + sum);
		
		
		

	}

}
