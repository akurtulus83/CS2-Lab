package java_first;

public class printting_HelloWord_and_JavaProgrammingIsEasy {
	
	public static void main(String[] args) {
		//Declaration of strings
		String word_1;
		String word_2;
		//giving the sentences to strings
		word_1="Hello Word";
		word_2="Java Programming is easy.";
		//giving to method to process 
		System.out.println(word_1);
		System.out.println(word_2);
		
	
	}
}
